# node-unblocker-heroku

## Information: 
    This code is made primarily for deployment to heroku but can be used on any Node.JS server. For the purpose of simplicity and since Heroku deployment is the intended environment for this code, all instructions are for Heroku.

## Setup:

1. Fork this repo
2. Press the "Deploy to Heroku" button below.
3. Make your changes to the text fields in public/index.html if you so wish.
4. Go to your heroku dashboard and then to settings and redeploy with the changes you've made.

This is technically against ToS and while the rules aren't really enforced on Heroku don't come crying to me if your deployment is deleted or locked for ToS.

Contact me if you want: fistonal@protonmail.com

## Deploy


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)




Special thanks to:
https://github.com/nfriedly - Developer of the original source code for this project
